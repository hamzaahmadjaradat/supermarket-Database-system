import tkinter as tk
import mysql.connector as con
from tkinter import ttk
import mysql.connector



root = tk.Tk()
root.title("Products")
root.geometry("900x500")
root.configure(background="gray")


table = ttk.Treeview()

table.place(x=0,y=0)
style = ttk.Style()
style.configure("Treeview", background="gray")
table.pack()
table["columns"] = ("productID", "name", "quantity", "unit", "category", "supplierID", "price")
table.column("productID", width=100)
table.column("name", width=100)
table.column("quantity", width=100)
table.column("unit", width=100)
table.column("category", width=100)
table.column("supplierID", width=100)
table.column("price", width=100)



table.heading("productID", text="productID")
table.heading("name", text="name")
table.heading("quantity", text="quantity")
table.heading("unit", text="unit")
table.heading("category", text="category")
table.heading("supplierID", text="supplierID")
table.heading("price", text="price")
style = ttk.Style()
style.configure("table.Heading", background="gray")

connection = mysql.connector.connect(host="localhost", user="root",
password="root", database="supermarket"
    )

cursor = connection.cursor()

cursor.execute("SELECT * FROM Products")

data = cursor.fetchall()

cursor.close()
connection.close()
for item in table.get_children():
        table.delete(item)
for row in data:
        table.insert("", tk.END, values=row)


root.mainloop()
